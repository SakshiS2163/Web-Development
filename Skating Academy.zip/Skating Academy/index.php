<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Speed Riders Skating Academy Registration</title>
  <link rel="stylesheet" href="style.css"> 

</head>
<body>
  <div class="container">
  <h1>Speed Riders Skating Academy</h1>
  <p class="utility">Registered new skaters for admission and camps</p>
    <form action="process.php" method="POST" id="registrationForm">
      <label for="name">Name:</label>
      <input type="text" id="name" name="name" required>

      <label for="gender">Gender:</label>
      <select id="gender" name="gender" required>
        <option value="m">Male</option>
        <option value="f">Female</option>
      </select>

      <label for="school">School Name:</label>
      <input type="text" id="school" name="school" required>

      <label for="contact">Contact Details:</label>
      <input type="tel" id="contact" name="contact" required>

      <label for="birthdate">Birth Date:</label>
      <input type="date" id="birthdate" name="birthdate" required>

      <label for="address">Address / City:</label>
      <input type="text" id="address" name="address" required>

      <button type="submit">Register</button>

    </form>
  </div>

  <script src="script.js"></script> 
</body>
</html>
