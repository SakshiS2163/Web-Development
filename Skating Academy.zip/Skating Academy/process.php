<?php

$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "speedriders_db"; //(Database name) 

$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Validate and sanitize input data (example validation)
  $name = $_POST["name"] ?? '';
  $gender = $_POST["gender"] ?? '';
  $school = $_POST["school"] ?? '';
  $contact = $_POST["contact"] ?? '';
  $birthdate = $_POST["birthdate"] ?? '';
  $address = $_POST["address"] ?? '';

  // Example validation (you should implement proper validation)
  if (empty($name) || empty($school) || empty($contact)) {
      echo '<div style="text-align: center; margin: 50px;">
              <h2 style="color: red;">Registration Failed</h2>
              <p>Please fill out all required fields.</p>
              <p><a href="index.php">Back to Registration Form</a></p>
            </div>';
  } else {
      // Process successful registration
      // Save to database, send confirmation email, etc.
      echo '<div style="text-align: center; margin: 50px;">
              <h2 style="color: green;">Registration Successful</h2>
              <p>Thank you for registering with Speed Riders Skating Academy!</p>
              <p>We look forward to welcoming you to our academy!</p>
              <p><a href="index.php">Back to Registration Form</a></p>
            </div>';
  }
} else {
  // Redirect or handle other cases as needed
  header("Location: index.php");
  exit;
}
?>
