document.addEventListener("DOMContentLoaded", function() {

    const form = document.getElementById("registrationForm");
    form.addEventListener("submit", function(event) {
        event.preventDefault();

        // Validate form inputs before submission
        if (validateForm()) {
            // If validation passes, submit the form
            form.submit();
        } else {
            // If validation fails, show an error message or handle it as needed
            alert("Please fill out all fields.");
        }
    });

    // Function to validate form inputs
    function validateForm() {
        const name = document.getElementById("name").value;
        const school = document.getElementById("school").value;
        const contact = document.getElementById("contact").value;
        const birthdate = document.getElementById("birthdate").value;
        const address = document.getElementById("address").value;

        // Basic validation: check if all fields are filled
        if (name.trim() === "" || school.trim() === "" || contact.trim() === "" || birthdate.trim() === "" || address.trim() === "") {
            return false;
        }

        return true;
    }

});
